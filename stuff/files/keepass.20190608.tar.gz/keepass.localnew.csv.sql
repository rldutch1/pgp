/*
Created by: Robert Holland
Date: 20190608
Purpose: Load keepass comma separated export file (.csv) into a MySQL database table.
*/

create database keepass;
use keepass;

CREATE TABLE `remote` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kpgroup` text,
  `title` text,
  `username` text,
  `password` text,
  `url` text,
  `notes` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

load data local infile 'keepass.localnew.csv' into table remote fields terminated by ',' enclosed by '"' lines terminated by '\n' (kpgroup, title, username, password, url, notes);

